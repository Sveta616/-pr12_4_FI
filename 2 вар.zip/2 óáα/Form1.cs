﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2_вар
{
    public partial class Form1 :Form
    {

        public Form1 ()
        {
            InitializeComponent();
        }
        public int i = 0;



        private void button1_Click_1 (object sender, EventArgs e)
        {
            Flower[] flower1 = new Flower[10];
            
                flower1[i] = new Flower();
                listBox1.Items[i]= Convert.ToString(flower1[i].Nameflower(textBox1.Text));
                listBox1.Items[i] = listBox1.Items[i]+" " + Convert.ToString(flower1[i].Typeflower(textBox2.Text));
                listBox1.Items[i] = listBox1.Items[i] + " " + Convert.ToString(flower1[i].Ottenokflower(textBox3.Text));
                listBox1.Items[i] = listBox1.Items[i] + " " + Convert.ToString(flower1[i].Countryflower(textBox4.Text));
            listBox1.Items[i] = listBox1.Items[i] + " " + Convert.ToString(flower1[i].Priceflower(textBox5.Text));
          listBox1.Items[i] = listBox1.Items[i] + " " + Convert.ToString(flower1[i].Dlinaflower(textBox6.Text));
            listBox1.Items[i] = listBox1.Items[i] + " " + Convert.ToString(flower1[i].Sez(textBox8.Text));
            listBox1.Items[i] = listBox1.Items[i] + " " + Convert.ToString(flower1[i].Cl(textBox9.Text));
            i++;
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == ""||textBox5.Text=="" || textBox6.Text==""||textBox7.Text==""||textBox8.Text==""||textBox9.Text=="")
            {
                MessageBox.Show("пустая строка,введите значение");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}