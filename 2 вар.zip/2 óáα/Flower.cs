﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_вар
{
    public class Flower
    { 
        public string name;
        public string type;
        public string ottenok;
        public string country;
        public int price;
        public double dlina;
        public string sezon;
        public string clas;
        public string Nameflower (string text)
            {
            name = text;
            return name;
            }
        public string Typeflower(string text)
        {
            type = text;
            return type;
        }
        public string Ottenokflower(string text)
        {
           ottenok = text;
            return ottenok;
        }
        public string Countryflower(string text)
        {
            country = text;
            return country;
        }
        public string Priceflower(string text)
        {
          
                string a = "Введите корректно";
                price = Convert.ToInt32(text);
                if (price <= 0)
                {
                    return a;
                }
                else
                    return Convert.ToString(price);
          }
      
        public string Dlinaflower(string text)
        {

            string a = "Введите корректно";
            dlina = Convert.ToDouble(text);
            if (dlina<=0)
            {
                return a;
            }
            else
                return Convert.ToString(dlina);

      
        }
        //доп метод
       public string Sez(string text)
        {
            sezon = text;
            return sezon;
        }
        //доп метод
        public string Cl(string text)
        {
            clas = text;
            return clas;
        }

        public void Schet(string text)
        {
            price = price * Convert.ToInt32(text);
        }
       
    }

 }

